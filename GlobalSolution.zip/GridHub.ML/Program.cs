﻿namespace GridHub.ML
{
    public class Program
    {

    }
}
